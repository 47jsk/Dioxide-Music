/**
@code Design By Mughal
@for support join https://discord.gg/rfzop
**/
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "seek",
  aliases: ["jump"],
  category: "Music",
  desc: "Seek to a specific time in the current track",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: true,
    player: { playing: true, active: true },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      if (!args.length) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: "Music", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Seek")
          .setDescription("Jump to a specific timestamp in the current song.")
          .addFields(
            { name: "Usage", value: "`+seek <time>` (in seconds or mm:ss)", inline: false },
            { name: "Aliases", value: "`jump`", inline: false },
            { name: "\u200B", value: "[] → optional\n<> → required\nDo **NOT** type these symbols when using commands!" }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [embed] });
      }

      if (!message.member.voice.channel) {
        const embed = new EmbedBuilder()
          .setDescription("You must be in a **voice channel** to seek.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] }).then(x => setTimeout(() => x.delete().catch(() => {}), 5000));
      }

      const player = client.kazagumo.players.get(message.guild.id);
      if (!player || !player.queue.current) {
        const embed = new EmbedBuilder()
          .setDescription("No song is currently playing.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] });
      }

      await client.music.Seek(message, args[0]);
    } catch (e) {
      console.error(e);
      const embed = new EmbedBuilder()
        .setDescription("Failed to seek to that position.")
        .setColor("Red");
      return message.channel.send({ embeds: [embed] });
    }
  },
};
