/**
@code Design By Mughal
@for support join https://discord.gg/rfzop
**/
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "replay",
  aliases: ["wapis"],
  category: "Music",
  desc: "Replay the current song from the beginning",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: true,
    player: { playing: true, active: true },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      // Show help embed if just +replay with no args
      if (!args.length) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: "Music", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Replay")
          .setDescription("Restart the currently playing song from the beginning.")
          .addFields(
            { name: "Usage", value: "`+replay`", inline: false },
            { name: "Aliases", value: "`wapis`", inline: false },
            { name: "\u200B", value: "[] → optional\n<> → required\nDo **NOT** type these symbols when using commands!" }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [embed] });
      }

      // Must be in voice channel
      if (!message.member.voice.channel) {
        const embed = new EmbedBuilder()
          .setDescription("You must be in a **voice channel** to replay music.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] })
          .then(x => setTimeout(() => x.delete().catch(() => {}), 5000));
      }

      const player = client.kazagumo.players.get(message.guild.id);
      if (!player) {
        const embed = new EmbedBuilder()
          .setDescription("I'm not connected to any voice channel.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] })
          .then(x => setTimeout(() => x.delete().catch(() => {}), 5000));
      }

      if (!player.queue.current) {
        const embed = new EmbedBuilder()
          .setDescription("There is no song currently playing.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] })
          .then(x => setTimeout(() => x.delete().catch(() => {}), 5000));
      }

      player.seek(0);

      const successEmbed = new EmbedBuilder()
        .setDescription(`⏮️ Replaying **${player.queue.current.title}** from the beginning!`)
        .setColor(client.config.color)
        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

      return message.channel.send({ embeds: [successEmbed] });

    } catch (e) {
      console.error(e);
      const embed = new EmbedBuilder()
        .setDescription("An error occurred while trying to replay the song.")
        .setColor("Red");
      return message.channel.send({ embeds: [embed] });
    }
  },
};
