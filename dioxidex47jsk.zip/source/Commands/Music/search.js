/**
@code Design By Mughal
@for support join https://discord.gg/rfzop
**/
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "search",
  aliases: ["find"],
  category: "Music",
  desc: "Search for a track without playing immediately",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: false,
    player: { playing: false, active: false },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      if (!args.length) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: "Music", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Search")
          .setDescription("Search YouTube/Spotify/SoundCloud tracks.")
          .addFields(
            { name: "Usage", value: "`+search <query>`", inline: false },
            { name: "Aliases", value: "`find`", inline: false },
            { name: "\u200B", value: "[] → optional\n<> → required\nDo **NOT** type these symbols when using commands!" }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [embed] });
      }

      if (!message.member.voice.channel) {
        const embed = new EmbedBuilder()
          .setDescription("You need to join a **voice channel** first.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] }).then(x => setTimeout(() => x.delete().catch(() => {}), 5000));
      }

      await client.music.Search(message, args.join(" "));
    } catch (e) {
      console.error(e);
      const embed = new EmbedBuilder()
        .setDescription("Error occurred while searching for tracks.")
        .setColor("Red");
      return message.channel.send({ embeds: [embed] });
    }
  },
};
