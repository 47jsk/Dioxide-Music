/** 
@code Design By Mughal 
@for support join https://discord.gg/rfzop
**/
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "skip",
  aliases: ["s", "next"],
  category: "Music",
  desc: "Skips the current song",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: true,
    player: { playing: true, active: true },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      // Show help embed if just +skip with no args
      if (!args.length) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: "Music", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Skip")
          .setDescription("Skip the currently playing track.")
          .addFields(
            { name: "Usage", value: "`+skip`", inline: false },
            { name: "Aliases", value: "`s`, `next`", inline: false },
            { name: "\u200B", value: "[] → optional argument\n<> → required argument\nDo **NOT** type these symbols when using commands!" }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [embed] });
      }

      if (!message.member.voice.channel) {
        const embed = new EmbedBuilder()
          .setDescription("You need to be in a **voice channel** to skip songs.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] })
          .then(x => setTimeout(() => x.delete().catch(() => {}), 5000));
      }

      const player = client.kazagumo.players.get(message.guild.id);
      if (!player || !player.queue.current) {
        const embed = new EmbedBuilder()
          .setDescription("There is no song playing to skip.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] })
          .then(x => setTimeout(() => x.delete().catch(() => {}), 5000));
      }

      await client.music.Skip(message);

    } catch (e) {
      console.error(e);
      const embed = new EmbedBuilder()
        .setDescription("An error occurred while skipping the track.")
        .setColor("Red");
      return message.channel.send({ embeds: [embed] });
    }
  },
};
