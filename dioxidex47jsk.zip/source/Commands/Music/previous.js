/** 
@code Design By Mughal 
@for support join https://discord.gg/rfzop
**/
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "previous",
  aliases: ["prev"],
  category: "Music",
  desc: "Play the Previous Music!",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: true,
    player: { playing: false, active: true },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      if (!args.length) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: "Music", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Previous")
          .setDescription("Play the previously played track in the queue.")
          .addFields(
            { name: "Usage", value: "`+previous`", inline: false },
            { name: "Aliases", value: "`prev`", inline: false },
            { name: "\u200B", value: "[] → optional argument\n<> → required argument\nDo **NOT** type these symbols when using commands!" }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [embed] });
      }

      // existing logic unchanged
      if (!message.member.voice.channel) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: `You need to be in a voice channel to use this command`, iconURL: message.author.displayAvatarURL() })
          .setColor(client.config.color);
        return message.channel.send({ embeds: [embed] }).then((x) => setTimeout(() => x.delete(), 5000));
      }
      client.music.Previous(message);
    } catch (e) {
      console.log(e);
    }
  },
};
