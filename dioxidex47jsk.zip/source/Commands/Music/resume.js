/** 
@code Design By Mughal 
@for support join https://discord.gg/rfzop
**/
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "resume",
  aliases: ["r"],
  category: "Music",
  desc: "Resume the Music!",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: true,
    player: { playing: false, active: false },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      // show command help embed if no args
      if (!args.length) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: "Music", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Resume")
          .setDescription("Resume the currently paused track.")
          .addFields(
            { name: "Usage", value: "`+resume`", inline: false },
            { name: "Aliases", value: "`r`", inline: false },
            { name: "\u200B", value: "[] → optional argument\n<> → required argument\nDo **NOT** type these symbols when using commands!" }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [embed] });
      }

      // must be in voice channel
      if (!message.member.voice.channel) {
        const embed = new EmbedBuilder()
          .setDescription("You need to be in a **voice channel** to resume music.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
      }

      const player = client.kazagumo.players.get(message.guild.id);
      if (!player || !player.queue.current) {
        const embed = new EmbedBuilder()
          .setDescription("There is no paused track to resume.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] });
      }

      await client.music.Resume(message);

    } catch (e) {
      console.error(e);
      const embed = new EmbedBuilder()
        .setDescription("An error occurred while resuming music. Please try again.")
        .setColor("Red");
      return message.channel.send({ embeds: [embed] });
    }
  },
};
