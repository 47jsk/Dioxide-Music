/**
@code Design By Mughal
@for support join https://discord.gg/rfzop
**/
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "shuffle",
  aliases: ["mix"],
  category: "Music",
  desc: "Shuffle the current queue",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: true,
    player: { playing: true, active: true },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      if (!args.length) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: "Music", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Shuffle")
          .setDescription("Randomize the current song queue.")
          .addFields(
            { name: "Usage", value: "`+shuffle`", inline: false },
            { name: "Aliases", value: "`mix`", inline: false },
            { name: "\u200B", value: "[] → optional\n<> → required\nDo **NOT** type these symbols when using commands!" }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [embed] });
      }

      if (!message.member.voice.channel) {
        const embed = new EmbedBuilder()
          .setDescription("You must join a **voice channel** first.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] }).then(x => setTimeout(() => x.delete().catch(() => {}), 5000));
      }

      const player = client.kazagumo.players.get(message.guild.id);
      if (!player || !player.queue.length) {
        const embed = new EmbedBuilder()
          .setDescription("There is nothing to shuffle.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] });
      }

      await client.music.Shuffle(message);
    } catch (e) {
      console.error(e);
      const embed = new EmbedBuilder()
        .setDescription("Error occurred while shuffling the queue.")
        .setColor("Red");
      return message.channel.send({ embeds: [embed] });
    }
  },
};
