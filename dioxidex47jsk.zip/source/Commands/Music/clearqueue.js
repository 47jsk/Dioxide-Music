/** 
@code Design By Mughal 
@for support join https://discord.gg/rfzop
**/
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "clear",
  aliases: ["clearqueue", "cq"],
  category: "Music",
  desc: "Clear the Queue!",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: true,
    player: { playing: false, active: true },
    premium: false,
    vote: false,
  },
  run: async ({ client, message, args }) => {
    try {
      if (!args.length) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: "Music", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Clear")
          .setDescription("Removes all songs from the current queue.")
          .addFields(
            { name: "Usage", value: "`+clear`", inline: false },
            { name: "Aliases", value: "`clearqueue`, `cq`", inline: false },
            { name: "\u200B", value: "[] → optional argument\n<> → required argument\nDo **NOT** type these symbols when using commands!" }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [embed] });
      }

      // existing logic unchanged
      if (!message.member.voice.channel) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: `You need to be in a voice channel to use this command`, iconURL: message.author.displayAvatarURL() })
          .setColor(client.config.color);
        return message.channel.send({ embeds: [embed] }).then((x) => setTimeout(() => x.delete(), 5000));
      }
      let player = await client.kazagumo.players.get(message.guild.id);
      player.queue.clear();
      const embed = new EmbedBuilder()
        .setAuthor({ name: `Queue Cleared by ${message.author.globalName}`, iconURL: message.author.displayAvatarURL() })
        .setColor(client.config.color);
      return message.channel.send({ embeds: [embed] });
    } catch (e) {
      console.log(e);
    }
  },
};
