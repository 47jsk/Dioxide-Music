/** 
@code Design By Mughal 
@for support join https://discord.gg/rfzop
**/
const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "queue",
  aliases: ["q"],
  category: "Music",
  desc: "Show the Queue!",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: true,
    player: { playing: false, active: true },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      // show command help embed if no args
      if (!args.length) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: "Music", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Queue")
          .setDescription("Displays the current music queue with upcoming tracks.")
          .addFields(
            { name: "Usage", value: "`+queue`", inline: false },
            { name: "Aliases", value: "`q`", inline: false },
            { name: "\u200B", value: "[] → optional argument\n<> → required argument\nDo **NOT** type these symbols when using commands!" }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [embed] });
      }

      // must be in voice channel
      if (!message.member.voice.channel) {
        const embed = new EmbedBuilder()
          .setDescription("You need to be in a **voice channel** to view the queue.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
      }

      const player = client.kazagumo.players.get(message.guild.id);
      if (!player || !player.queue || !player.queue.length) {
        const embed = new EmbedBuilder()
          .setDescription("There is nothing in the queue right now.")
          .setColor("Red");
        return message.channel.send({ embeds: [embed] });
      }

      // use client.music.Queue to show the queue (existing functionality)
      await client.music.Queue(message);

    } catch (e) {
      console.error(e);
      const embed = new EmbedBuilder()
        .setDescription("An error occurred while displaying the queue. Please try again.")
        .setColor("Red");
      return message.channel.send({ embeds: [embed] });
    }
  },
};
