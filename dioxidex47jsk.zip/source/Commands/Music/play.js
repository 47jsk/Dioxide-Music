/**
@code Design By Mughal 
@for support join https://discord.gg/rfzop
**/

const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "play",
  aliases: ["p"],
  category: "Music",
  desc: "Play a song of your favorite choice",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: false,
    player: {
      playing: false,
      active: false,
    },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      if (!message.member.voice.channel) {
        const payload = {
          content: "- You need to be in a **voice channel** to play music.",
        };
        return client.message.send(message, payload);
      }

      const query = args.join(" ");
      if (!query) {
        const embed = new EmbedBuilder()
          .setAuthor({ name: "Music", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Play")
          .setDescription("Loads your input and adds it to the queue.")
          .addFields(
            { name: "Usage", value: "`+play <query>`", inline: false },
            { name: "Aliases", value: "`p`", inline: false },
            {
              name: "\u200B",
              value: "[] → optional argument\n<> → required argument\nDo **NOT** type these symbols when using commands!"
            }
          )
          .setColor(0xff0000) // RED color
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();

        return message.channel.send({ embeds: [embed] });
      }

      await client.music.Play(message, query);
    } catch (error) {
      console.error(error);
    }
  },
};
