/**
 * @code Design By Vampy
 * @for support join https://discord.gg/rfzop
 */

const { 
  EmbedBuilder, 
  ActionRowBuilder, 
  StringSelectMenuBuilder, 
  ButtonBuilder, 
  ButtonStyle 
} = require("discord.js");

module.exports = {
  name: "help",
  aliases: ["h", "commands"],
  category: "Info",
  desc: "View all commands in an interactive menu.",
  dev: false,
  options: {
    owner: false,
    inVc: false,
    sameVc: false,
    player: { active: false, playing: false },
    premium: false,
    vote: false,
  },

  run: async ({ client, message }) => {
    try {
      // --- FULL HELP MENU ONLY ---
      const categories = {};
      client.commands.forEach((cmd) => {
        const cat = cmd.category || "Misc";
        if (!categories[cat]) categories[cat] = [];
        categories[cat].push(cmd.name);
      });

      const mainEmbed = new EmbedBuilder()
        .setColor(client.config.color)
        .setImage('https://cdn.discordapp.com/attachments/1396113597649784882/1407738558608838716/bc3f7db1-e566-4d0b-9e31-8bb17f18b124.jpg?ex=68a73232&is=68a5e0b2&hm=8888978d47c6bf0e0196170d1e0aba0274fbcb51e27cd1b888435ec6372dbcb1&')
        .setAuthor({ name: "DioxideHelp Menu", iconURL: client.user.displayAvatarURL() })
        .setDescription(
          `**Hie ${message.author.globalName || message.author.username}! Dioxide Music Here**\n\n` +
          `<a:Dioxide:1417365087269814332> No prefix required — just type any command directly!\n\n` +
          `<a:Dioxide:1417365087269814332> **Total Commands:** ${client.commands.size}\n\n` +
            
 `<:Playy:1417367482951270441> **Music**\n` +

 `<:Filters:1417365824892829786> **Filters**\n` +

 `<:Dioxutik:1417365619753488445> **Config**\n`+

 `<:Vampykapehlapyar:1417367863257469040> **Premium**`
        )
        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
        .setTimestamp();
      // --- Dropdown for categories ---
      const selectOptions = Object.keys(categories).map((cat) => ({
        label: cat,
        value: cat,
        description: `${categories[cat].length} commands`,
      }));

      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId("help_category")
        .setPlaceholder("Select a command category")
        .addOptions(selectOptions);

      // --- Buttons for actions ---
      const buttonRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel("Invite")
          .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
          .setStyle(ButtonStyle.Link)
          .setEmoji("<:invite:1407689936647487628>"),
        new ButtonBuilder()
          .setLabel("Support")
          .setURL("https://discord.gg/rfzop")
          .setStyle(ButtonStyle.Link)
          .setEmoji("<:support:1407694130863280269>"),
        new ButtonBuilder()
          .setLabel("Vote")
          .setURL(client.config.vote || "https://top.gg")
          .setStyle(ButtonStyle.Link)
          .setEmoji("<:vote:1407693881683742783>")
      );

      const row = new ActionRowBuilder().addComponents(selectMenu);

      const helpMsg = await message.channel.send({ 
        embeds: [mainEmbed], 
        components: [row, buttonRow] 
      });

      const collector = helpMsg.createMessageComponentCollector({
        time: 300000, // 5 minutes
        filter: (interaction) => interaction.user.id === message.author.id,
      });

      collector.on("collect", async (interaction) => {
        await interaction.deferUpdate();
        const cat = interaction.values[0];
        const cmds = categories[cat].map((c) => `\`${c}\``).join(", ");

        const catEmbed = new EmbedBuilder()
          .setColor(client.config.color)
          .setAuthor({ name: `Dioxide Help - ${cat}`, iconURL: client.user.displayAvatarURL() })
          .setDescription(`**Commands in ${cat}:**\n${cmds || "None"}`)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
          .setTimestamp();

        await helpMsg.edit({ embeds: [catEmbed], components: [row, buttonRow] }).catch(() => {});
      });

      collector.on("end", () => {
        helpMsg.edit({ components: [] }).catch(() => {});
      });
    } catch (err) {
      console.error("Help command error:", err);
      const errorEmbed = new EmbedBuilder()
        .setColor(0xff0000)
        .setAuthor({ name: "Error", iconURL: client.user.displayAvatarURL() })
        .setDescription("❌ Something went wrong while showing the help menu.")
        .setFooter({ text: "Designed by Hauser" });
      return message.channel.send({ embeds: [errorEmbed] });
    }
  },
};
