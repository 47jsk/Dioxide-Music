/**
 * @code Design By Vampy
 * @for support join https://discord.gg/rfzop
 */

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  name: "ping",
  aliases: ["p"],
  category: "Misc",
  permission: "",
  desc: "Shows advanced ping and bot statistics",
  dev: false,
  options: {
    owner: false,
    inVc: false,
    sameVc: false,
    player: { playing: false, active: false },
    premium: false,
    vote: false,
  },
  run: async ({ client, message, args, guildData }) => {
    try {
      // 10-second cooldown
      const userId = message.author.id;
      const now = Date.now();
      const cooldownTime = 10 * 1000;
      const cooldowns = new Map();
      if (cooldowns.has(userId)) {
        const expirationTime = cooldowns.get(userId) + cooldownTime;
        if (now < expirationTime) {
          const timeLeft = ((expirationTime - now) / 1000).toFixed(1);
          return message.reply(`<:Time:1417368312899436625> Please wait ${timeLeft} seconds before using ping again.`).catch(console.error);
        }
      }
      cooldowns.set(userId, now);

      // Calculate metrics
      const msg = await message.channel.send("Checking ping...").catch(console.error);
      const botLatency = msg.createdTimestamp - message.createdTimestamp;
      const apiLatency = client.ws.ping;
      const uptime = `${Math.floor(client.uptime / 86400000)}d ${Math.floor((client.uptime % 86400000) / 3600000)}h ${Math.floor((client.uptime % 3600000) / 60000)}m`;
      const memoryUsage = `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`;

      // Initial embed
      const pingEmbed = new EmbedBuilder()
        .setColor(client.config.color)
        .setAuthor({ name: "Dioxide Ping Stats", iconURL:'https://cdn.discordapp.com/emojis/1407673517142704150.gif?size=48&name=hacker_botping' })
        .setDescription(
          `<:Home:1417368563882397777> **Ping Results for <@${message.author.id}>**\n\n` +
          `<:Ping:1417368689707057155> **Bot Latency**: ${botLatency}ms\n` +
          `<:Jsjsi:1417368884893319199> **API Latency**: ${apiLatency}ms\n` +
          `<:Time:1417368312899436625> **Uptime**: ${uptime}\n` +
           `<:Heheh:1417369210681561119> **Prefix**: \`Global NoPrefix\`\n` +
          `<:Links:1417369506346700813> **Support**: [Join Here](https://discord.gg/rfzop)`
        )
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setFooter({
          text: `Requested by ${message.author.globalName || message.author.tag} | Designed by Hauser`,
          iconURL: message.author.displayAvatarURL({ dynamic: true }),
        });

      // Action rows with buttons
      const actionRow1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("refresh_ping")
          .setLabel("Refresh")
          .setStyle(ButtonStyle.Primary)
          .setEmoji("<:filters:1407691885237113033>"),
        new ButtonBuilder()
          .setCustomId("detailed_log")
          .setLabel("Detailed Log")
          .setStyle(ButtonStyle.Secondary)
          .setEmoji("<:util:1407678147805319198>"),
        new ButtonBuilder()
          .setLabel("Invite Dioxide")
          .setStyle(ButtonStyle.Link)
          .setEmoji("<:invite:1407689936647487628>")
          .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
      );

      // Send initial message
      await msg.edit({ content: null, embeds: [pingEmbed], components: [actionRow1] }).catch(console.error);

      // Collector for button interactions
      const collector = msg.createMessageComponentCollector({ time: 300000 }); // 5 minutes

      collector.on("collect", async (interaction) => {
        if (interaction.user.id !== message.author.id) {
          return interaction.reply({
            content: "📢 This is for the command user only!",
            ephemeral: true,
          }).catch(console.error);
        }

        try {
          await interaction.deferUpdate();

          if (interaction.customId === "refresh_ping") {
            const newMsg = await message.channel.send("📡 Rechecking ping...").catch(console.error);
            const newBotLatency = newMsg.createdTimestamp - message.createdTimestamp;
            const newApiLatency = client.ws.ping;
            const newUptime = `${Math.floor(client.uptime / 86400000)}d ${Math.floor((client.uptime % 86400000) / 3600000)}h ${Math.floor((client.uptime % 3600000) / 60000)}m`;
            const newMemoryUsage = `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`;

            const refreshedEmbed = new EmbedBuilder()
              .setColor(client.config.color)
              .setAuthor({ name: "Dioxide Ping Stats", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
              .setDescription(
                `<a:Pong:1417370194883510282> **Updated Ping Results for <@${message.author.id}>**\n\n` +
                `<:Ping:1417368689707057155> **Bot Latency**: ${newBotLatency}ms\n` +
                `<:Jsjsi:1417368884893319199> **API Latency**: ${newApiLatency}ms\n` +
                `<:Time:1417368312899436625> **Uptime**: ${newUptime}\n` +
                `📡 **Servers**: ${client.guilds.cache.size}\n` +
                `👥 **Users**: ${client.users.cache.size}\n` +
                `<:Cpu:1417370890395582465> **Memory Usage**: ${newMemoryUsage}\n\n` +
                `<:Heheh:1417369210681561119> **Prefix**: \`${guildData.prefix ?? "?"}\`\n` +
                `<:Links:1417369506346700813> **Support**: [Join Here](https://discord.gg/rfzop)`
              )
              .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
              .setFooter({
                text: `Requested by ${message.author.globalName || message.author.tag} | Designed by Hauser`,
                iconURL: message.author.displayAvatarURL({ dynamic: true }),
              });

            await newMsg.edit({ content: null, embeds: [refreshedEmbed], components: [actionRow1] }).catch(console.error);
          } else if (interaction.customId === "detailed_log") {
            const detailedEmbed = new EmbedBuilder()
              .setColor(client.config.color)
              .setAuthor({ name: "Dioxide Detailed Stats", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
              .setDescription(
                `<a:Pong:1417370194883510282> **Detailed Stats for <@${message.author.id}>**\n\n` +
                `<a:Dioxide:1417365087269814332> **Bot Latency**: ${botLatency}ms (Message round-trip)\n` +
                `<a:Dioxide:1417365087269814332> **API Latency**: ${apiLatency}ms (WebSocket ping)\n` +
                `<a:Dioxide:1417365087269814332> **Uptime Breakdown**: ${Math.floor(client.uptime / 86400000)} days, ${Math.floor((client.uptime % 86400000) / 3600000)} hours, ${Math.floor((client.uptime % 3600000) / 60000)} minutes\n` +
                `<a:Dioxide:1417365087269814332> **Guild Count**: ${client.guilds.cache.size} servers\n` +
                `<a:Dioxide:1417365087269814332> **User Count**: ${client.users.cache.size} users\n` +
                `<a:Dioxide:1417365087269814332>**Memory Usage**: ${memoryUsage} (Heap Used)\n` +
                `<a:Dioxide:1417365087269814332>**Node Version**: ${process.version}\n` +
                `<a:Dioxide:1417365087269814332> **Support**: [Join Here](https://discord.gg/rfzop)`
              )
              .setFooter({
                text: `Requested by ${message.author.globalName || message.author.tag} | Designed by Hauser`,
                iconURL: message.author.displayAvatarURL({ dynamic: true }),
              });
            await interaction.editReply({ embeds: [detailedEmbed], components: [actionRow1] });
          }
        } catch (error) {
          console.error("Interaction error:", error);
          await interaction.followUp({
            content: "📢 An error occurred. Please try again later.",
            ephemeral: true,
          }).catch(console.error);
        }
      });

      collector.on("end", () => {
        msg.edit({ components: [] }).catch(console.error);
      });

    } catch (error) {
      console.error("Ping command error:", error);
      message.channel.send("📢 An error occurred while checking ping. Please try again.").catch(() => {
        message.author.send("📢 I can’t send in this channel. Check my permissions or contact support [here](https://discord.gg/rfzop).").catch(() => {});
      });
    }
  },
};