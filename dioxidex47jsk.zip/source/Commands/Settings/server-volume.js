/**
@code Design By Mughal
@for support join https://discord.gg/rfzop
**/
const guildSchema = require("../../Models/Guild");
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
} = require("discord.js");

module.exports = {
  name: "server-volume",
  aliases: ["volume", "svolume"],
  category: "Settings",
  permission: "ManageGuild",
  desc: "Set the default server volume and apply to the current player",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: true,
    player: { playing: false, active: true },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      // Permission
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
        const e = new EmbedBuilder()
          .setDescription("You need the **Manage Server** permission to change the server volume.")
          .setColor(0xff0000);
        return message.channel.send({ embeds: [e] })
          .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
      }

      // Ensure DB doc + defaults
      let guildData = await guildSchema.findOne({ id: message.guild.id });
      if (!guildData) {
        guildData = await guildSchema.findOneAndUpdate(
          { id: message.guild.id },
          { $setOnInsert: { id: message.guild.id, prefix: "+", settings: { volume: 100 } } },
          { upsert: true, new: true, setDefaultsOnInsert: true }
        );
      }
      if (!guildData.settings) guildData.settings = {};
      if (typeof guildData.settings.volume !== "number") guildData.settings.volume = 100;

      const player = client.kazagumo.players.get(message.guild.id);

      // No numeric arg → help/status + interactive adjusters
      if (!args[0]) {
        const e = new EmbedBuilder()
          .setAuthor({ name: "Server Volume", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: Server Volume")
          .setDescription("Set the default playback volume for this server.")
          .addFields(
            { name: "Current Default", value: `\`${guildData.settings.volume}\``, inline: true },
            { name: "Usage", value: "`+server-volume <1-200>`", inline: false },
            {
              name: "Tip",
              value: "Use the buttons below to quickly adjust and apply to the current player (if any).",
              inline: false
            }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("vol_down_10").setLabel("-10").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId("vol_down_5").setLabel("-5").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId("vol_reset").setLabel("Reset 100").setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId("vol_up_5").setLabel("+5").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId("vol_up_10").setLabel("+10").setStyle(ButtonStyle.Secondary),
        );

        const msg = await message.channel.send({ embeds: [e], components: [row] });
        const collector = msg.createMessageComponentCollector({ time: 30_000 });

        collector.on("collect", async (i) => {
          if (i.user.id !== message.author.id) {
            return i.reply({ ephemeral: true, content: "This control isn't for you." });
          }
          try {
            let newVol = guildData.settings.volume;
            if (i.customId === "vol_reset") newVol = 100;
            if (i.customId === "vol_down_10") newVol -= 10;
            if (i.customId === "vol_down_5") newVol -= 5;
            if (i.customId === "vol_up_5") newVol += 5;
            if (i.customId === "vol_up_10") newVol += 10;

            newVol = Math.min(200, Math.max(1, newVol));

            await guildSchema.findOneAndUpdate(
              { id: message.guild.id },
              { $set: { "settings.volume": newVol } },
              { new: true }
            );

            if (client.kazagumo.players.get(message.guild.id)) {
              client.kazagumo.players.get(message.guild.id).setVolume(newVol);
            }

            guildData.settings.volume = newVol;

            await i.update({
              embeds: [
                EmbedBuilder.from(e)
                  .spliceFields(0, 1, { name: "Current Default", value: `\`${newVol}\``, inline: true })
              ],
              components: [row],
            });
          } catch (err) {
            console.error(err);
            return i.update({ content: "Failed to update volume.", components: [] });
          }
        });

        collector.on("end", () => {
          msg.edit({ components: [] }).catch(() => {});
        });

        return;
      }

      // Numeric argument path
      if (isNaN(args[0])) {
        const e = new EmbedBuilder()
          .setDescription("Please provide a **number** for the volume (1–200).")
          .setColor(0xff0000);
        return message.channel.send({ embeds: [e] })
          .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
      }

      const volume = Math.min(200, Math.max(1, parseInt(args[0], 10)));

      await guildSchema.findOneAndUpdate(
        { id: message.guild.id },
        { $set: { "settings.volume": volume } },
        { new: true }
      );

      if (player) player.setVolume(volume);

      const ok = new EmbedBuilder()
        .setColor(client.config.color)
        .setAuthor({ name: `${message.guild.name} Volume`, iconURL: message.guild.iconURL() })
        .setDescription(`**Volume Changed** to \`${volume}\``)
        .setFooter({ text: `Updated by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

      return message.channel.send({ embeds: [ok] });
    } catch (e) {
      console.error(e);
      const er = new EmbedBuilder()
        .setDescription("An error occurred while updating the volume.")
        .setColor(0xff0000);
      return message.channel.send({ embeds: [er] });
    }
  },
};
