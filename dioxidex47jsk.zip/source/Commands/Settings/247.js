/**
@code Design By Mughal
@for support join https://discord.gg/rfzop
**/
const guildSchema = require("../../Models/Guild");
const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
} = require("discord.js");

module.exports = {
  name: "247",
  aliases: ["always-on", "alwayson", "24-7", "24/7"],
  category: "Settings",
  permission: "ManageGuild",
  desc: "Toggle or configure 24/7 mode",
  dev: false,
  options: {
    owner: false,
    inVc: true,
    sameVc: false,
    player: { playing: false, active: false },
    premium: false,
    vote: false,
  },

  run: async ({ client, message, args }) => {
    try {
      // Permission check (extra safety in addition to your framework field)
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
        const e = new EmbedBuilder()
          .setDescription("You need the **Manage Server** permission to manage 24/7 mode.")
          .setColor(0xff0000);
        return message.channel.send({ embeds: [e] })
          .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
      }

      // Load or bootstrap guild settings
      let guildData = await guildSchema.findOne({ id: message.guild.id });
      if (!guildData) guildData = await new guildSchema({ id: message.guild.id }).save();

      // Normalize structure
      if (!guildData.twentyFourSeven) {
        guildData.twentyFourSeven = { enabled: false, textChannel: null, voiceChannel: null };
      }

      const inVc = message.member.voice.channel;
      const currentState = guildData.twentyFourSeven.enabled;

      // If no args -> show help/status + interactive controls
      if (!args.length) {
        const status = currentState ? "Enabled" : "Disabled";
        const statusEmoji = currentState ? "🟢" : "🔴";
        const e = new EmbedBuilder()
          .setAuthor({ name: "Music Settings", iconURL: client.user.displayAvatarURL() })
          .setTitle("Command: 24/7 Mode")
          .setDescription("Keep the bot in your voice channel 24/7 (even when idle).")
          .addFields(
            { name: "Usage", value: "`+247 <on|off>`\n`+247 toggle`", inline: false },
            {
              name: "Current Status",
              value:
                `${statusEmoji} **${status}**\n` +
                `• Text: ${guildData.twentyFourSeven.textChannel ? `<#${guildData.twentyFourSeven.textChannel}>` : "`Not set`"}\n` +
                `• Voice: ${guildData.twentyFourSeven.voiceChannel ? `<#${guildData.twentyFourSeven.voiceChannel}>` : "`Not set`"}`,
              inline: false
            },
            {
              name: "\u200B",
              value: "[] → optional\n<> → required\nDo **NOT** type these symbols when using commands!"
            }
          )
          .setColor(0xff0000)
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("247_on").setLabel("Enable").setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId("247_off").setLabel("Disable").setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId("247_set_here").setLabel("Bind to this channel").setStyle(ButtonStyle.Primary)
        );

        const msg = await message.channel.send({ embeds: [e], components: [row] });
        const collector = msg.createMessageComponentCollector({ time: 30_000 });

        collector.on("collect", async (i) => {
          if (i.user.id !== message.author.id) {
            return i.reply({ ephemeral: true, content: "This control isn't for you." });
          }

          try {
            if (i.customId === "247_set_here") {
              if (!inVc) return i.update({ content: "Join a **voice channel** first.", components: [] });
              guildData.twentyFourSeven.textChannel = message.channel.id;
              guildData.twentyFourSeven.voiceChannel = inVc.id;
              await guildData.save();
              return i.update({ content: `Bound 24/7 to ${message.channel} / <#${inVc.id}>.`, components: [] });
            }

            const turnOn = i.customId === "247_on" ? true : false;
            if (turnOn) {
              if (!inVc) return i.update({ content: "Join a **voice channel** to enable 24/7.", components: [] });

              guildData.twentyFourSeven.enabled = true;
              guildData.twentyFourSeven.textChannel = message.channel.id;
              guildData.twentyFourSeven.voiceChannel = inVc.id;
              await guildData.save();

              // Ensure player is created & connected
              let player = client.kazagumo.players.get(message.guild.id);
              if (!player) await client.music.CreateAvonPlayer(message);
              else {
                await message.guild.members.me.voice.setChannel(inVc.id);
                await player.setVoiceChannel(inVc.id);
              }

              return i.update({ content: "✅ **24/7 Enabled.** I will stay in this voice channel.", components: [] });
            } else {
              guildData.twentyFourSeven.enabled = false;
              await guildData.save();

              const player = client.kazagumo.players.get(message.guild.id);
              if (player) player.destroy();

              return i.update({ content: "🛑 **24/7 Disabled.** I will leave when idle.", components: [] });
            }
          } catch (err) {
            console.error(err);
            return i.update({ content: "An error occurred while updating 24/7 mode.", components: [] });
          }
        });

        collector.on("end", () => {
          msg.edit({ components: [] }).catch(() => {});
        });

        return;
      }

      // Arguments: on/off/toggle
      const sub = String(args[0]).toLowerCase();
      if (!["on", "off", "enable", "disable", "true", "false", "toggle"].includes(sub)) {
        const e = new EmbedBuilder()
          .setDescription("Invalid option. Use `+247 on`, `+247 off`, or `+247 toggle`.")
          .setColor(0xff0000);
        return message.channel.send({ embeds: [e] })
          .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
      }

      if (["toggle"].includes(sub)) {
        args[0] = currentState ? "off" : "on";
      }

      if (["on", "enable", "true"].includes(args[0])) {
        if (!inVc) {
          const e = new EmbedBuilder()
            .setDescription("Join a **voice channel** to enable 24/7 mode.")
            .setColor(0xff0000);
        return message.channel.send({ embeds: [e] })
            .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
        }

        guildData.twentyFourSeven.enabled = true;
        guildData.twentyFourSeven.textChannel = message.channel.id;
        guildData.twentyFourSeven.voiceChannel = inVc.id;
        await guildData.save();

        let player = client.kazagumo.players.get(message.guild.id);
        if (!player) await client.music.CreateAvonPlayer(message);
        else {
          await message.guild.members.me.voice.setChannel(inVc.id);
          await player.setVoiceChannel(inVc.id);
        }

        const ok = new EmbedBuilder()
          .setColor(client.config.color)
          .setAuthor({ name: `${message.guild.name} 24/7 Mode`, iconURL: message.guild.iconURL() })
          .setDescription(`🟢 **Enabled**\n• Text: ${message.channel}\n• Voice: <#${inVc.id}>`)
          .setFooter({ text: `Updated by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [ok] });
      } else {
        guildData.twentyFourSeven.enabled = false;
        await guildData.save();

        const player = client.kazagumo.players.get(message.guild.id);
        if (player) player.destroy();

        const ok = new EmbedBuilder()
          .setColor(client.config.color)
          .setAuthor({ name: `${message.guild.name} 24/7 Mode`, iconURL: message.guild.iconURL() })
          .setDescription("🔴 **Disabled**")
          .setFooter({ text: `Updated by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
        return message.channel.send({ embeds: [ok] });
      }
    } catch (error) {
      console.error("Error in 247 command:", error);
      const e = new EmbedBuilder()
        .setDescription("An error occurred while updating 24/7 mode.")
        .setColor(0xff0000);
      return message.channel.send({ embeds: [e] });
    }
  },
};
