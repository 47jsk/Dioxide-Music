const { ActionRowBuilder, ButtonBuilder, EmbedBuilder } = require("discord.js");

module.exports = {

  name: "dev",

  aliases: ["team", "developers"],

  category: "Misc",

  dev: true,

  options: {

    owner: true,

    inVc: false,

    sameVc: false,

    player: {

      playing: false,

      active: false,

    },

    premium: false,

    vote: false,

  },

  run: async ({ client, message, args }) => {

    const embed = new EmbedBuilder()

      .setColor("00ecff") // You can change the color

      .setTitle("Development Team")

      .setDescription("Meet the team behind the bot!")

      .addFields(

        { name: "<:Hehe:1385570711229173872> Owner & Lead Developer", value: "Hauser", inline: true }, // Replace with actual owner name

        { name: "<:Hah:1385901918160945237> Developer", value: "!       Ꮩᴀᴍᴘɪʀᴇ   </>", inline: true } // Replace with actual developer name

      )

      .setTimestamp()

      .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });

    const row = new ActionRowBuilder().addComponents(

      new ButtonBuilder()

        .setLabel("Support Server")

        .setStyle("Link")

        .setURL("https://discord.gg/dates"), // Replace with your support server link

      new ButtonBuilder()

        .setLabel("Invite Bot")

        .setStyle("Link")

        .setURL("https://discord.com/oauth2/authorize?client_id=YOUR_BOT_ID&scope=bot&permissions=8") // Replace with your bot's invite link

    );

    await message.reply({ embeds: [embed], components: [row] });

  },

};