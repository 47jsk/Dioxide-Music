const { ActionRowBuilder, ButtonBuilder, EmbedBuilder, ButtonStyle } = require("discord.js");

module.exports = {
  name: "serverlist",
  aliases: ["guilds", "servers"],
  category: "Misc",
  dev: true,
  options: {
    owner: true,
    inVc: false,
    sameVc: false,
    player: {
      playing: false,
      active: false,
    },
    premium: false,
    vote: false,
  },
  run: async ({ client, message }) => {
    // Get all guilds and sort them alphabetically
    const guilds = client.guilds.cache
      .sort((a, b) => a.name.localeCompare(b.name))
      .map(guild => ({ name: guild.name, id: guild.id }));

    if (!guilds.length) {
      const embed = new EmbedBuilder()
        .setColor(client.config.color || "#FF0000") // Fallback to red if client.config.color is undefined
        .setDescription("The bot is not in any servers.")
        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    const itemsPerPage = 10; // Number of guilds per page
    let currentPage = 0;

    // Function to generate embed for a specific page
    const generateEmbed = (page) => {
      const start = page * itemsPerPage;
      const end = start + itemsPerPage;
      const pageGuilds = guilds.slice(start, end);

      const embed = new EmbedBuilder()
        .setColor(client.config.color || "#2F3136") // Use client.config.color or fallback
        .setTitle(`Bot Server List (Page ${page + 1}/${Math.ceil(guilds.length / itemsPerPage)})`)
        .setDescription(
          pageGuilds
            .map((guild, index) => `${start + index + 1}. **${guild.name}** - \`${guild.id}\``)
            .join("\n") || "No servers on this page."
        )
        .setFooter({
          text: `Requested by ${message.author.tag} | Total Servers: ${guilds.length}`,
          iconURL: message.author.displayAvatarURL(),
        })
        .setTimestamp();

      return embed;
    };

    // Function to generate buttons
    const generateButtons = (page) => {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("prev_page")
          .setLabel("Previous")
          .setStyle(ButtonStyle.Primary)
          .setDisabled(page === 0),
        new ButtonBuilder()
          .setCustomId("next_page")
          .setLabel("Next")
          .setStyle(ButtonStyle.Primary)
          .setDisabled(page === Math.ceil(guilds.length / itemsPerPage) - 1),
        new ButtonBuilder()
          .setCustomId("generate_invite")
          .setLabel("Generate Invite")
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setLabel("Support Server")
          .setStyle(ButtonStyle.Link)
          .setURL("https://discord.gg/your-server-link") // Replace with your support server link
      );
      return row;
    };

    // Send initial embed
    const initialEmbed = generateEmbed(currentPage);
    const initialButtons = generateButtons(currentPage);
    const sentMessage = await message.reply({ embeds: [initialEmbed], components: [initialButtons] });

    // Create button interaction collector
    const filter = (i) => i.user.id === message.author.id;
    const collector = sentMessage.createMessageComponentCollector({
      filter,
      time: 5 * 60 * 1000, // 5 minutes
    });

    collector.on("collect", async (interaction) => {
      await interaction.deferUpdate();

      if (interaction.customId === "prev_page") {
        currentPage--;
      } else if (interaction.customId === "next_page") {
        currentPage++;
      } else if (interaction.customId === "generate_invite") {
        // Prompt user to enter a server number
        const promptEmbed = new EmbedBuilder()
          .setColor(client.config.color || "#2F3136")
          .setDescription("Please enter the server number (e.g., `1` for the first server) to generate an invite link.")
          .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
          .setTimestamp();

        await interaction.followUp({ embeds: [promptEmbed], ephemeral: true });

        // Create a message collector for server number
        const messageFilter = (m) => m.author.id === message.author.id;
        const messageCollector = message.channel.createMessageCollector({
          filter: messageFilter,
          max: 1,
          time: 30 * 1000, // 30 seconds to respond
        });

        messageCollector.on("collect", async (msg) => {
          const serverNumber = parseInt(msg.content.trim(), 10);

          if (isNaN(serverNumber) || serverNumber < 1 || serverNumber > guilds.length) {
            const errorEmbed = new EmbedBuilder()
              .setColor(client.config.color || "#FF0000")
              .setDescription(`Invalid server number. Please enter a number between 1 and ${guilds.length}.`)
              .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
              .setTimestamp();
            return interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
          }

          const guild = client.guilds.cache.get(guilds[serverNumber - 1].id);

          if (!guild) {
            const errorEmbed = new EmbedBuilder()
              .setColor(client.config.color || "#FF0000")
              .setDescription(`Server with number ${serverNumber} not found.`)
              .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
              .setTimestamp();
            return interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
          }

          // Try to generate an invite link (using first text channel with permission)
          const channel = guild.channels.cache
            .filter((ch) => ch.isTextBased() && guild.members.me.permissionsIn(ch).has("CreateInstantInvite"))
            .first();

          if (!channel) {
            const errorEmbed = new EmbedBuilder()
              .setColor(client.config.color || "#FF0000")
              .setDescription(`No text channel found in \`${guild.name}\` where I have permission to create an invite.`)
              .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
              .setTimestamp();
            return interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
          }

          try {
            const invite = await channel.createInvite({
              maxAge: 86400, // 24 hours
              maxUses: 1, // Single use
              reason: `Invite generated by ${message.author.tag} via serverlist command`,
            });

            const inviteEmbed = new EmbedBuilder()
              .setColor(client.config.color || "#00FF00")
              .setDescription(`Invite for **${guild.name}**: [Click here](${invite.url})`)
              .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
              .setTimestamp();

            await interaction.followUp({ embeds: [inviteEmbed], ephemeral: true });
          } catch (error) {
            const errorEmbed = new EmbedBuilder()
              .setColor(client.config.color || "#FF0000")
              .setDescription(`Failed to create invite for \`${guild.name}\`: \`\`\`${error.message}\`\`\``)
              .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
              .setTimestamp();
            return interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
          }
        });

        messageCollector.on("end", (collected) => {
          if (!collected.size) {
            const timeoutEmbed = new EmbedBuilder()
              .setColor(client.config.color || "#FF0000")
              .setDescription("No server number provided within 30 seconds.")
              .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
              .setTimestamp();
            interaction.followUp({ embeds: [timeoutEmbed], ephemeral: true });
          }
        });

        return; // Don't update the embed for invite button
      }

      // Update embed and buttons for pagination
      const updatedEmbed = generateEmbed(currentPage);
      const updatedButtons = generateButtons(currentPage);
      await interaction.update({ embeds: [updatedEmbed], components: [updatedButtons] });
    });

    collector.on("end", () => {
      // Disable buttons when collector ends
      const disabledButtons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("prev_page")
          .setLabel("Previous")
          .setStyle(ButtonStyle.Primary)
          .setDisabled(true),
        new ButtonBuilder()
          .setCustomId("next_page")
          .setLabel("Next")
          .setStyle(ButtonStyle.Primary)
          .setDisabled(true),
        new ButtonBuilder()
          .setCustomId("generate_invite")
          .setLabel("Generate Invite")
          .setStyle(ButtonStyle.Success)
          .setDisabled(true),
        new ButtonBuilder()
          .setLabel("Support Server")
          .setStyle(ButtonStyle.Link)
          .setURL("https://discord.gg/your-server-link") // Replace with your support server link
      );

      sentMessage.edit({ components: [disabledButtons] }).catch(() => {});
    });
  },
};