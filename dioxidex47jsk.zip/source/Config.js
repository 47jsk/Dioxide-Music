module.exports = {
  token: {
    manaspapa:
      "MTQyMTg2ODg2NzQ5MTMzNjI4Mg.GbF1RB.l0p1iCP0D2Uezn-0H120rttLnuK3q-8E5TYkOE",
    manaspapa2:

      "MTQyMjlwMjYyMzQ2OTI5MzU3MA.G14Gxj.S10fgRM7APOjspWsH7xglN5XsO4SwVslrEamQA",
   
  },
  tokenTopgg: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjkwNDMxNzE0MTg2NjY0NzU5MiIsImJvdCI6dHJ1ZSwiaWF0IjoxNjczNTI3OTYzfQ.WwA0KXh_nAQcBmR7BPqgLGyElYZheTQmguQfA2F6aNc",
  mongoURL: {
    Primary: "mongodb+srv://SpaceMusic:shivmop@cluster0.kg.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    Secondary: "mongodb+srv://Kronix1:arjun@cluster0.ob9wwsc.mongodb.net/?retryWrites=true&w=majority",
  },
  clusterMode: "DEVELOPMENT",
  def_prefix: "?",
  vote_bypass: ["1265342847956156500", "1265342847956156500"],
  vote:`https://top.gg/bot/1300534329402982472/vote`,
  developers: ["1265342847956156500", "884085314082197544"],
  managers: ["abc", "def"],
  support: "https://discord.gg/dates",
  invite: "https://discord.com/oauth2/authorize?client_id=1421868867491336282&permissions=3391975360822087&integration_type=0&scope=bot",
  color: "#00ecff",
  webhook: {
    guildAdd: `https://discord.com/api/webhooks/1422639091350241292/U5_c1qSS6ykwnC4owznfyzvCznHJBGO1YkNb7wARzK0xNg0KQF1wZCuholBILhnSsCSb`,
    guildRemove: `https://discord.com/api/webhooks/1422639091350241292/U5_c1qSS6ykwnC4owznfyzvCznHJBGO1YkNb7wARzK0xNg0KQF1wZCuholBILhnSsCSb`,
    commandRun: `https://discord.com/api/webhooks/1422639091350241292/U5_c1qSS6ykwnC4owznfyzvCznHJBGO1YkNb7wARzK0xNg0KQF1wZCuholBILhnSsCSb`,
  },
  LOGGINGS: {
    guildAdd:
      "https://discord.com/api/webhooks/1422639091350241292/U5_c1qSS6ykwnC4owznfyzvCznHJBGO1YkNb7wARzK0xNg0KQF1wZCuholBILhnSsCSb",
    guildRemove:
      "https://discord.com/api/webhooks/1422639091350241292/U5_c1qSS6ykwnC4owznfyzvCznHJBGO1YkNb7wARzK0xNg0KQF1wZCuholBILhnSsCSb",
    commandRun:
      "https://discord.com/api/webhooks/1422639091350241292/U5_c1qSS6ykwnC4owznfyzvCznHJBGO1YkNb7wARzK0xNg0KQF1wZCuholBILhnSsCSb",
  },
  nodes: [
  
  {
      name: "lavalink.serenetia.com",
      url: "lavalink.serenetia.com:80",
      auth: "discord.gg/ajidevserver",
      secure: false,
  },

  
  ],
};
