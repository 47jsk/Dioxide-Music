/**
 * @code Design By Vampy
 * @for support join https://discord.gg/rfzop
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  WebhookClient,
} = require("discord.js");
const guildSchema = require("../../Models/Guild");
const userSchema = require("../../Models/User");

// Cooldown storage for mention help menu
const mentionCooldowns = new Map();

module.exports = async (client, message) => {
  try {
    if (message.author.bot || message.channel.type === 1) return;

    // Fetch or create guild data with default prefix "?"
    const guildData = await guildSchema.findOneAndUpdate(
      { id: message.guild.id },
      { $setOnInsert: { id: message.guild.id, prefix: "?" } },
      { upsert: true, new: true, setDefaultsOnInsert: true, lean: true }
    );

    // ===== Mention help menu =====
    const mentionRegex = new RegExp(`^<@!?${client.user.id}>$`);
    if (message.content.match(mentionRegex)) {
      const userId = message.author.id;
      const now = Date.now();
      const cooldownTime = 15 * 1000;

      if (mentionCooldowns.has(userId)) {
        const expirationTime = mentionCooldowns.get(userId) + cooldownTime;
        if (now < expirationTime) {
          const timeLeft = ((expirationTime - now) / 1000).toFixed(1);
          return message.reply(`Echo needs a nap! Wait ${timeLeft}s before calling again.`);
        }
      }
      mentionCooldowns.set(userId, now);

      const createLoadingEmbed = (progress) => {
        const progressBar = "<:dioxide:1417363663370715187>".repeat(progress) + "<:Dioxide:1417364503812903015>".repeat(10 - progress);
        return new EmbedBuilder()
          .setColor(client.config.color)
          .setTitle("Dioxide is Waking Up!")
          .setDescription(
            `**Getting Ready...**\n${progressBar} ${progress * 10}%\n\n` +
            `Dioxide is getting ready for <@${message.author.id}>... 💖`
          )
          .setFooter({
            text: "Designed by Hauser",
            iconURL: message.author.displayAvatarURL({ dynamic: true }),
          });
      };

      const loadingSteps = async (message) => {
        const mentionMessage = await message.channel.send({ embeds: [createLoadingEmbed(0)] });
        for (let i = 1; i <= 10; i++) {
          await new Promise((resolve) => setTimeout(resolve, 200));
          await mentionMessage.edit({ embeds: [createLoadingEmbed(i)] }).catch(console.error);
        }
        return mentionMessage;
      };
        const totalMembers = client.guilds.cache.reduce((sum, guild) => sum + guild.memberCount, 0);

      const getSpotlightCommand = () => {
        const musicCommands = client.commands
          .filter((cmd) => cmd.category === "Music")
          .map((cmd) => ({
            name: cmd.name || "Unknown",
            desc: cmd.desc || "No description available",
          }));
        return musicCommands[Math.floor(Math.random() * musicCommands.length)] || {
          name: "play",
          desc: "Play a song or playlist",
        };
      };

      const mentionEmbed = new EmbedBuilder()
        .setColor(client.config.color)
        .setAuthor({
          name: "Dioxide: Your Ultimate Music Bot",
          iconURL: client.user.displayAvatarURL({ dynamic: true }),
        })
        .setDescription(
          `**Hie <@${message.author.id}>!** I'm **Dioxide**, your pokie music buddy! 💖\n\n` +
          `<a:Dioxide:1417365087269814332> **Features**: Music, playlists, and queue fun!\n` +
          `<a:Dioxide:1417365087269814332> **Commands**: Just type \`help\`, no prefix needed!\n` +
          `<a:Dioxide:1417365087269814332> **Support**: Join [here](https://discord.gg/rfzop).\n` +
          `<a:Dioxide:1417365087269814332> **Invite**: Add me [here](https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands).\n\n` +
          `<a:Dioxide:1417365087269814332> **Fun Fact**: Made with love by Hauser`
        )
        .addFields(
          {
            name: `<:Filters:1417365824892829786> Stats`,
            value: `**Uptime**: ${Math.floor(client.uptime / 3600000)}h ${Math.floor((client.uptime % 3600000) / 60000)}m\n` +
                   `**Servers**: ${client.guilds.cache.size}\n` +
                   `**Users**: ${totalMembers}`,
            inline: true,
          },
          {
            name: `<:Dioxutik:1417365619753488445> Music Spotlight`,
            value: `**${getSpotlightCommand().name}**\n${getSpotlightCommand().desc}`,
            inline: false,
          }
        )
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setImage("https://cdn.discordapp.com/attachments/1308870168738529460/1325763604049297440/pookie-music_1736157046.png")
        .setFooter({
          text: `Requested by ${message.author.globalName || message.author.tag} | Designed by Hauser`,
          iconURL: message.author.displayAvatarURL({ dynamic: true }),
        });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel("Invite Dioxide")
          .setEmoji("<:invite:1407689936647487628>")
          .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)
          .setStyle(ButtonStyle.Link)
      );

      const mentionMessage = await loadingSteps(message);
      await mentionMessage.edit({ embeds: [mentionEmbed], components: [row] }).catch(() => {});
      return; // stop here if only mention
    }

    // ===== PREFIXLESS COMMAND HANDLER =====
    const args = message.content.trim().split(/ +/);
    const commandName = args.shift().toLowerCase();
    const cmd =
      client.commands.get(commandName) ||
      client.commands.find((c) => c.aliases && c.aliases.includes(commandName));
    if (!cmd) return; // message is not a command

    // permission checks
    const botMember = await message.guild.members.fetch(client.user.id);
    const needed = ["SendMessages", "ViewChannel", "EmbedLinks", "UseExternalEmojis", "Connect", "Speak"]
      .filter(p => !botMember.permissions.has(p));
    if (needed.length) return sendError(`I need: ${needed.join(", ")}`);

    if (cmd.permission && !message.member.permissions.has(cmd.permission))
      return sendError(`You need **${cmd.permission}** permission.`);
    if (cmd.dev && !client.config.developers.includes(message.author.id))
      return sendError(`This command is for developers only.`);
    if (cmd.options.owner && !client.config.developers.includes(message.author.id))
      return sendError(`This command is for owners only.`);

    if (cmd.options.inVc && !message.member.voice.channel)
      return sendError(`Join a voice channel first.`);
    const player = client.kazagumo.players.get(message.guild.id);
    if (cmd.options.player.active && !player)
      return sendError(`No player active. Try reconnecting.`);
    if (cmd.options.player.playing && (!player || !player.queue.current))
      return sendError(`No track playing currently.`);

    if (cmd.options.premium && !guildData.premium)
      return sendError(`This is for premium servers only.`);

    if (cmd.options.vote) {
      const voted = await client.topgg.hasVoted(message.author.id);
      if (!voted) {
        const voteEmbed = new EmbedBuilder()
          .setColor(0xff0000)
          .setAuthor({ name: "Vote Required", iconURL: message.author.displayAvatarURL() })
          .setDescription(`-<:nein:1407327327213326468> <@${message.author.id}> Vote for Echo on [Top.gg](${client.config.vote}) to use this!`)
          .setFooter({ text: "Designed by Hauser" });
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setLabel("Vote").setEmoji("👍").setURL(client.config.vote).setStyle(ButtonStyle.Link)
        );
        return message.channel.send({ embeds: [voteEmbed], components: [row] });
      }
    }

    // run the command
    await cmd.run({ client, message, args, prefix: "", guildData, player }).catch(e => {
      console.error(e);
      sendError("An error occurred. Contact support: https://discord.gg/rfzop");
    });

    // Send success embed after command execution
    await sendSuccess(`Command **${cmd.name}** executed successfully!`);
    await logCommandExecution(client, message, cmd, args);
    await updateUserData(message.author.id, cmd.name);

  } catch (error) {
    console.error("Error in message event:", error);
  }
};

async function logCommandExecution(client, message, cmd, args) {
  try {
    if (client.config.LOGGINGS?.commandRun) {
      let commandWeb = new WebhookClient({ url: client.config.LOGGINGS.commandRun });
      await commandWeb.send({
        embeds: [
          new EmbedBuilder()
            .setColor(client.config.color)
            .setDescription(
              `- **Command Author**: [${message.author.globalName || message.author.username}](https://discord.com/users/${message.author.id})\n` +
              `- **Command Channel**: [${message.channel.name}](https://discord.com/channels/${message.guild.id}/${message.channel.id})\n` +
              `- **Command Guild**: ${message.guild.name} (\`${message.guild.id}\`)\n` +
              `- **Command Used at**: <t:${Math.round(Date.now() / 1000)}:R>\n` +
              `- **Command**: ${cmd.name}\n` +
              `- **Command Arguments**: ${args.join(" ") || "No Arguments"}`
            )
            .setAuthor({ name: "Command Run Logging", iconURL: message.guild.iconURL() || client.user.displayAvatarURL() })
            .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: "Designed by Vampy", iconURL: client.user.displayAvatarURL({ dynamic: true }) }),
        ],
      });
    }
  } catch (error) {
    console.error("Error logging command execution:", error);
  }
}

async function updateUserData(userId, commandName) {
  try {
    const updateData = { $inc: { commandsUsed: 1 } };
    if (commandName === "play") {
      updateData.$inc.songsPlayed = 1;
    }
    await userSchema.findOneAndUpdate({ id: userId }, updateData, {
      new: true,
      upsert: true,
      setDefaultsOnInsert: true,
    });
  } catch (error) {
    console.error("Error updating user data:", error);
  }
}