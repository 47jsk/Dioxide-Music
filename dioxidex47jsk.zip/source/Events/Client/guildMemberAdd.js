const { EmbedBuilder, Events } = require("discord.js");

module.exports = (client) => {
  client.on(Events.GuildMemberAdd, async (member) => {
    try {
      // Welcome channel ID jahan msg bhejna hai
      const channelId = "1395470804640333826"; 
      const channel = member.guild.channels.cache.get(channelId);
      if (!channel) return;

      const embed = new EmbedBuilder()
        .setColor("#ff0000")
        .setTitle("Welcome to the Server! Cutie")
        .setDescription(
          `*** 

<a:rd_BlackStarz321:1395818372629008384> Welcome ${member.user.username} To __CRIMINAL HEADQUARTERS__***

*** <a:Criminal_OP:1395818118823149588> Check Bot <#1395613614152487064>  ***

*** <a:Criminal_OP:1395818118823149588> Make TixZ For Help <#1395470800756408410> ***

*** <a:Criminal_OP:1395818118823149588> See Updates & AnnouncementZ <#1395470794838118611> ***

***Supporters Ko <a:heart:1375349344282083359>  You HaterZ Ki Mkc***`
        )
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 1024 }))
        .setFooter({ text: "ECHO LOVES MUSIC" })
        .setTimestamp();

      await channel.send({ content: `welcome <@${member.id}>`, embeds: [embed] });
    } catch (error) {
      console.error("Error sending welcome message:", error);
    }
  });
};