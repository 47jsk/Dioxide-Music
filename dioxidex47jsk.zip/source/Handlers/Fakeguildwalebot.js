const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  AttachmentBuilder,
  ChannelType,
} = require("discord.js");
const GuildSchema = require("../Models/Guild");
const { muzicard } = require("muzicard");

module.exports = async function AvonDispatcher(client, kazagumo) {
  kazagumo.on("playerStart", async (player, track) => {
    // Skip short tracks (less than 5 seconds)
    if (track.length < 5000) {
      player.skip();
      let channel = client.channels.cache.get(player.textId);
      if (channel) {
        channel.send({
          content: `<:ja:1407327210313875456> Track is less than **5 seconds**. Skipping the track.`,
        }).then((msg) => setTimeout(() => msg.delete(), 5000));
      }
      return;
    }

    let guildData = await GuildSchema.findOne({ id: player.guildId });
    const channel = client.channels.cache.get(player.textId);

    // Search track info via Spotify or another method
    let data = await client.spotify.searchTrack(track.title);
    let title, author, thumbnail, url, artistLink;
    let tezz = /^(https?\:\/\/)?(www\.)?(youtube\.com|youtu\.?be)\/.+$/;
    
    // Handle YouTube tracks differently
    if (tezz.test(track.uri)) {
      title = data.title ? data.title.replace(/[^a-zA-Z0-9 ]/g, "") : track.title.replace(/[^a-zA-Z0-9 ]/g, "");
      author = data.artist || client.user.username;
      thumbnail = data.thumbnail || track.thumbnail;
      url = data.link || track.uri;
      artistLink = data.artistLink || track.uri;
    } else {
      title = track.title;
      author = track.author;
      thumbnail = track.thumbnail;
      url = track.uri;
      artistLink = data.artistLink || track.uri;
    }

    player.queue.current.title = title;
    player.data.set("url", url);
    player.data.set("autoplayTrack", track);

    // Format requester info
    let ops = `[**${track.requester.globalName || track.requester.username}**](https://discord.com/users/${track.requester.id})`;

    client.utils.setVCStatus(player.voiceId, `Dioxide The Best Freemium Bot`);

    const nowPlaying = new EmbedBuilder()
      .setAuthor({ name: `Dioxide Controller`,
       iconURL: 'https://cdn.discordapp.com/emojis/1407321363123011644.gif?size=48&name=disc'
                 })
      .setImage("attachment://muzicard.png")
      .setColor(client.config.color)
      .setThumbnail(thumbnail)
      .addFields(
        {
          name: "<a:Dioxide:1417365087269814332> Played by",
          value: ops,
          inline: true,
        },
        {
          name: "<a:Dioxide:1417365087269814332> Song duration",
          value: track.isStream ? "Live" : await client.utils.convertTime(track.length),
          inline: true,
        }
      )
      .setFooter({
        text: `The Best Freemium Bot?`,
        iconURL: track.requester.displayAvatarURL({ dynamic: true }),
      });

    // Create muzicard (visual representation of the track)
    const isRadioMode = true;  // Replace with actual logic to determine radio mode
    const isAIDJMode = false;   // Replace with actual logic to determine AI DJ mode
    const card = new muzicard()
      .setName(isRadioMode ? "Dioxide" : isAIDJMode ? "AI DJ" : track.title)
      .setAuthor(isRadioMode ? "Best Freemium Bot" : isAIDJMode ? "AI DJ" : "Dioxide")
      .setColor(isRadioMode ? "#FF0000" : isAIDJMode ? "#FF0000" : "auto")
      .setTheme("classic")
      .setBrightness(isRadioMode ? 85 : isAIDJMode ? 70 : 69)
      .setThumbnail(track.thumbnail)
      .setProgress(isRadioMode ? 0 : 15)
      .setStartTime(isRadioMode ? "Dioxide" : isAIDJMode ? "AI DJ Live" : "0:10")
      .setEndTime(isRadioMode ? "Loves You" : isAIDJMode ? "Live" : track.length);

    const buffer = await card.build();
    if (!buffer) {
      console.error("Buffer is null or undefined");
      return;
    }

    const attachment = new AttachmentBuilder(buffer, { name: "muzicard.png" });

    // Buttons for the player controls (only one row)
    const buttonsRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("previous").setStyle(client.btn.grey).setEmoji("<:11prev:1288550025173143654>"),
      new ButtonBuilder().setCustomId("PauseAndResume").setStyle(client.btn.grey).setEmoji("<:11pause:1288549936107094056>"),
      new ButtonBuilder().setCustomId("stop").setStyle(client.btn.red).setEmoji("<:11pause:1288549936107094056>"),
      new ButtonBuilder().setCustomId("settings").setStyle(client.btn.grey).setEmoji("1131847099361792082"),
      new ButtonBuilder().setCustomId("skip").setStyle(client.btn.grey).setEmoji("<:11next:1288549983049486411>")
    );

    // Handle description for high volume
    if (player.volume > 100) {
      nowPlaying.setDescription(
        `**[${title.length > 30 ? `${title.slice(0, 30)}...` : title}](${url})** by [**${author}**](${artistLink})\n- **Note:** *Volume is slightly higher than usual, may cause distortion*`
      );
    } else {
      nowPlaying.setDescription(
        `**[${title.length > 30 ? `${title.slice(0, 30)}...` : title}](${url})** by [**${author}**](${artistLink})`
      );
    }

    // Send message with only first button row
    if (channel) {
      try {
        const msg = await channel.send({
          embeds: [nowPlaying],
          files: [attachment],
          components: [buttonsRow], // only one row
        });
        player.data.set("message", msg);
      } catch (err) {
        console.error("Failed to send message in the channel:", err);
      }
    } else {
      player.destroy();
      let channelGuild = client.guilds.cache.get(player.guildId);
      let channels = channelGuild.channels.cache.filter((c) => c.type === ChannelType.GuildText);
      await client.channels.cache
        .get(channels.first().id)
        .send({ content: `I can't find the text channel to send the message. So destroying the player.` })
        .then((msg) => setTimeout(() => msg.delete(), 8000))
        .catch((err) => console.error(err));
    }
  });

  // Event handler for when the player is moved
  kazagumo.on("playerMoved", async (player, state, channels) => {
    client.utils.removeVCStatus(player.voiceId);
    try {
      const newChannel = client.channels.cache.get(channels.newChannelId);
      const oldChannel = client.channels.cache.get(channels.oldChannelId);
      let channel = client.channels.cache.get(player.textId);
      if (channels.newChannelId === channels.oldChannelId) return;
      if (!channel) return;
      if (state === "UNKNOWN") {
        player.destroy();
        return channel.send({ content: `- Unable to move to the new channel. So Destroying the player.` })
          .then((msg) => setTimeout(() => msg.delete(), 8000));
      }
      if (state === "MOVED") {
        player.setVoiceChannel(channels.newChannelId);
        if (player.paused) player.pause(false);
        return channel.send({ content: `- Someone moved me from **${oldChannel.name}** to **${newChannel.name}**` })
          .then((msg) => setTimeout(() => msg.delete(), 8000));
      }
      if (state === "LEFT") {
        let data = await GuildSchema.findOne({ id: player.guildId });
        if (channels.newChannel) {
          player.setVoiceChannel(channels.newChannelId);
        } else {
          if (player) player.destroy();
          let shard = await client.guilds.cache.get(data.id).shardId;
          if (data.twentyFourSeven.enabled) {
            setTimeout(async () => {
              await client.kazagumo.createPlayer({
                guildId: data.id,
                textId: data.twentyFourSeven.textChannel,
                voiceId: data.twentyFourSeven.voiceChannel,
                shardId: shard,
                deaf: true,
              });
            }, 3000);
          } else {
            if (player) player.destroy();
            const oldChannel = client.channels.cache.get(channels.oldChannelId);
            return channel.send({ content: ` - I have been left from **${oldChannel.name}**. Destroying the player.` })
              .then((msg) => setTimeout(() => msg.delete(), 8000));
          }
        }
      }
    } catch (e) {
      const player = client.kazagumo.players.get(player.guildId);
      player.destroy();
    }
  });

  // Event handler for when the track is stuck
  kazagumo.on("playerStuck", async (player, data) => {
    client.utils.removeVCStatus(player.voiceId);
    const channel = client.channels.cache.get(player.textId);
    let msg = player.data.get("message").id;
    if (channel) {
      if (channel.messages.cache.get(msg)) {
        channel.messages.cache.get(msg).delete();
      }
    }
    console.warn(`Track is stuck for more than ${data.threshold}ms. Skipping the track in ${player.guildId}`);
    if (channel) {
      channel.send({ content: `- Track is stuck for more than ${data.threshold}ms. Skipping the track.` })
        .then((msg) => setTimeout(() => msg.delete(), 5000));
      player.skip();
    }
  });
};

/** 
@code Design By Mughal 
@for support join https://discord.gg/rfzop
**/
